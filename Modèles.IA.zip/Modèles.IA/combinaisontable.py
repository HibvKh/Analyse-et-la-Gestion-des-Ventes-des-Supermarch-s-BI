import pandas as pd

# Charger les fichiers CSV
table1 = pd.read_csv(r"C:\Users\hp\Downloads\databi\order_items_cleaning.csv")
table2 = pd.read_csv(r"C:\Users\hp\Downloads\databi\order_payments_cleaning.csv")
table3 = pd.read_csv(r"C:\Users\hp\Downloads\databi\orders_cleaning.csv")
table5 = pd.read_csv(r"C:\Users\hp\Downloads\databi\customers_cleaning (1).csv")
table6 = pd.read_csv(r"C:\Users\hp\Downloads\databi\products_cleaning.csv")

# Étape 1 : Joindre Table1 avec Table3 sur 'order_id'
merged1 = pd.merge(table1, table3, on='order_id', how='inner')

# Étape 2 : Joindre Table2 avec Table3 sur 'order_id'
merged2 = pd.merge(table2, table3, on='order_id', how='inner')

# Étape 3 : Joindre merged1 avec Table6 sur 'product_id'
merged3 = pd.merge(merged1, table6, on='product_id', how='inner')

# Étape 4 : Joindre merged3 avec merged2 sur 'order_id'
merged4 = pd.merge(merged3, merged2, on='order_id', how='inner')
merged4 = merged4.rename(columns={'customer_id_x': 'customer_id'})


# Étape 5 : Joindre merged4 avec Table5 sur 'customer_id'
final_table = pd.merge(merged4, table5, on='customer_id', how='inner')

print(final_table.columns)
# Renommer les colonnes pour les rendre cohérentes
final_table = final_table.rename(columns={
    'order_status_x': 'order_status',
    'order_purchase_timestamp_x': 'order_purchase_timestamp',
    'order_delivered_customer_date_x': 'order_delivered_customer_date',
    'order_estimated_delivery_date_x': 'order_estimated_delivery_date',
    'order_status_y': 'order_status_from_orders',
    'order_purchase_timestamp_y': 'order_purchase_timestamp_from_orders',
    'order_delivered_customer_date_y': 'order_delivered_customer_date_from_orders',
    'order_estimated_delivery_date_y': 'order_estimated_delivery_date_from_orders',
    'customer_id_y': 'customer_id_from_orders'
})

# Choisir les colonnes pertinentes pour la table finale
final_table = final_table[['price', 'payment_type',
    'order_status','customer_city', 'customer_state', 'product_category_name','order_purchase_timestamp'
]]

# Exporter la table combinée dans un fichier CSV
final_table.to_csv(r"C:\Users\hp\Downloads\databi\datacob.csv", index=False)


print("La table combinée a été créée avec succès et sauvegardée dans 'combined_table.csv'")

