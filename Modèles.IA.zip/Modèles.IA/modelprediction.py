import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error

# Charger les données
data = pd.read_csv(r"C:\Users\hp\Downloads\databi\datacob.csv")

# Convertir les dates et extraire l'année
data['order_purchase_timestamp'] = pd.to_datetime(data['order_purchase_timestamp'])
data['year'] = data['order_purchase_timestamp'].dt.year

# Regrouper par ville et année pour compter le nombre de clients
city_year_data = data.groupby(['customer_city', 'year']).size().reset_index(name='num_clients')

# Créer un DataFrame pivot pour avoir les années comme caractéristiques
pivot_data = city_year_data.pivot(index='customer_city', columns='year', values='num_clients').fillna(0)

# Réorganiser les données pour entraîner un modèle
X = pivot_data.loc[:, 2016:2018].values  # Années disponibles comme caractéristiques
y = pivot_data.loc[:, 2016:2018].sum(axis=1).values  # Somme des clients pour toutes les années

# Diviser les données en train et test
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Entraîner un modèle de Random Forest
model = RandomForestRegressor(random_state=42, n_estimators=100)
model.fit(X_train, y_train)

# Évaluer le modèle
y_pred = model.predict(X_test)
print("MAE:", mean_absolute_error(y_test, y_pred))

# Prédire pour 2020
X_2020 = pivot_data.loc[:, 2016:2018].values  # Utiliser toutes les villes pour prédire 2020
predictions_2020 = model.predict(X_2020)

# Ajouter les prédictions dans le DataFrame
pivot_data['predicted_2020'] = predictions_2020

# Sauvegarder les prédictions
pivot_data[['predicted_2020']].to_csv(r"C:\Users\hp\Downloads\databi\cusmcitypre.csv")
print(pivot_data[['predicted_2020']].head())
